/**
*Clase buscar.
*@author Fa venegas
*/


import java.io.*;
import java.util.Scanner;
import java.util.*;

public class Search{
	
	public void Busca(String archiCli,String archiO){
		Scanner s = new Scanner(System.in);
		System.out.print("Ingresa el id del cliente: ");
		String id=s.nextLine();
		try{
		List<String> list  = new ArrayList<>();
		Scanner lector; 
		lector = new Scanner(new FileReader(archiCli)); 

	
			while(lector.hasNextLine()){
				list.add(lector.nextLine());
			}

			if(list.contains(id)){
				BuscaO(archiO,id);
				


			}else{
				System.out.println("Persona "+id+ " no es Cliente");

			}
		}catch(IOException e){
			System.out.println("Error E/S: " + e);

		}
		
	}//fin del metodo BuscaC


	public void BuscaO(String archiO,String id){
		try{
		Scanner lector; 
		lector = new Scanner(System.in); 
		String datoAbuscar; 
		datoAbuscar=id;
		lector = new Scanner(new FileReader(archiO)); 
		while(lector.hasNextLine()){
			String pa=lector.next();
			if(pa.contains(datoAbuscar)){
				System.out.print("Creado reporte de: " +id );
				System.out.println(" ");
				FileWriter fw = new FileWriter("Reporte_"+id);
				fw.write(pa);
				fw.flush();
				}
			
		}	
	}catch(IOException e){
		System.out.println("Error E/S: " + e);
		}

	}//fin del metodo Busca


}//fin dela clase

