/**
*Clase buscar.
*@author Fa venegas
*/


public class Maneja{

	public static void main(String[] args) {
	

		Search c = new Search();
		String cli="Clientes.txt";
		String o="Ordenes.txt";	
		c.Busca(cli,o);
		

		
	}
	
}


